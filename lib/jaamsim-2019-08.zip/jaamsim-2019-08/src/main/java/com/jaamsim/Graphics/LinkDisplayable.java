/*
 * JaamSim Discrete Event Simulation
 * Copyright (C) 2016 JaamSim Software Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.jaamsim.Graphics;

import java.util.ArrayList;

import com.jaamsim.basicsim.Entity;
import com.jaamsim.math.Vec3d;

public interface LinkDisplayable {
	// Each link should only be registered once, so if an entity refers to another as a destination
	// that entity should NOT refer back to the first as a source
	public ArrayList<Entity> getDestinationEntities();
	public ArrayList<Entity> getSourceEntities();

	public Vec3d getSourcePoint();
	public Vec3d getSinkPoint();

	public double getRadius();
}
